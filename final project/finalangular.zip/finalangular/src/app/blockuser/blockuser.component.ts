import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-blockuser',
  templateUrl: './blockuser.component.html',
  styleUrls: ['./blockuser.component.css']
})
export class BlockuserComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
