import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addedit',
  templateUrl: './addedit.component.html',
  styleUrls: ['./addedit.component.css']
})
export class AddeditComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
