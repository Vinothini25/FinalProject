import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-searchheader',
  templateUrl: './searchheader.component.html',
  styleUrls: ['./searchheader.component.css']
})
export class SearchheaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
