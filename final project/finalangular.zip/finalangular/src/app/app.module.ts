import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { NavbarComponent } from './navbar/navbar.component';
import { SearchheaderComponent } from './searchheader/searchheader.component';
import { SearchnavbarComponent } from './searchnavbar/searchnavbar.component';
import { SearchbodyComponent } from './searchbody/searchbody.component';
import { SignupComponent } from './signup/signup.component';
import { SigninComponent } from './signin/signin.component';
import { Signin1Component } from './signin1/signin1.component';
import { AboutusComponent } from './aboutus/aboutus.component';
import { PaymentComponent } from './payment/payment.component';
import { BlocktrainerComponent } from './blocktrainer/blocktrainer.component';
import { BlockuserComponent } from './blockuser/blockuser.component';
import { AddeditComponent } from './addedit/addedit.component';
import { TraineracceptComponent } from './traineraccept/traineraccept.component';
import { UserrequestComponent } from './userrequest/userrequest.component';
import { Profile1Component } from './profile1/profile1.component';
import { Profile2Component } from './profile2/profile2.component';
import { Profile3Component } from './profile3/profile3.component';
import { Profile4Component } from './profile4/profile4.component';
import { CompletedComponent } from './completed/completed.component';
import { InprogressComponent } from './inprogress/inprogress.component';
import { UserprofileComponent } from './userprofile/userprofile.component'
import { FormsModule,ReactiveFormsModule }   from '@angular/forms';
import { EditskillsComponent } from './editskills/editskills.component';
@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    NavbarComponent,
    SearchheaderComponent,
    SearchnavbarComponent,
    SearchbodyComponent,
    SignupComponent,
    SigninComponent,
    Signin1Component,
    AboutusComponent,
    PaymentComponent,
    BlocktrainerComponent,
    BlockuserComponent,
    AddeditComponent,
    TraineracceptComponent,
    UserrequestComponent,
    Profile1Component,
    Profile2Component,
    Profile3Component,
    Profile4Component,
    CompletedComponent,
    InprogressComponent,
    UserprofileComponent,
    EditskillsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
