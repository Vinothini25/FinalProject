import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-searchnavbar',
  templateUrl: './searchnavbar.component.html',
  styleUrls: ['./searchnavbar.component.css']
})
export class SearchnavbarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
