import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-userrequest',
  templateUrl: './userrequest.component.html',
  styleUrls: ['./userrequest.component.css']
})
export class UserrequestComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
