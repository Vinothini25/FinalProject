import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-blocktrainer',
  templateUrl: './blocktrainer.component.html',
  styleUrls: ['./blocktrainer.component.css']
})
export class BlocktrainerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
