import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BlocktrainerComponent } from './blocktrainer.component';

describe('BlocktrainerComponent', () => {
  let component: BlocktrainerComponent;
  let fixture: ComponentFixture<BlocktrainerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BlocktrainerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BlocktrainerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
