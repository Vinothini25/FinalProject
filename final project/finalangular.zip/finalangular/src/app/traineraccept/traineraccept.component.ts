import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-traineraccept',
  templateUrl: './traineraccept.component.html',
  styleUrls: ['./traineraccept.component.css']
})
export class TraineracceptComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
