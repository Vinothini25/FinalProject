import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TraineracceptComponent } from './traineraccept.component';

describe('TraineracceptComponent', () => {
  let component: TraineracceptComponent;
  let fixture: ComponentFixture<TraineracceptComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TraineracceptComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TraineracceptComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
