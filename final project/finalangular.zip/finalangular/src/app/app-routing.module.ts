import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HeaderComponent } from './header/header.component';
import { NavbarComponent } from './navbar/navbar.component';
import { SearchheaderComponent } from './searchheader/searchheader.component';
import { SearchnavbarComponent } from './searchnavbar/searchnavbar.component';
import { SearchbodyComponent } from './searchbody/searchbody.component';
import { SignupComponent } from './signup/signup.component';
import { SigninComponent } from './signin/signin.component';
import { Signin1Component } from './signin1/signin1.component';
import { PaymentComponent } from './payment/payment.component';
import { AboutusComponent } from './aboutus/aboutus.component';
import { BlocktrainerComponent } from './blocktrainer/blocktrainer.component';
import { BlockuserComponent } from './blockuser/blockuser.component';
import { AddeditComponent } from './addedit/addedit.component';
import { TraineracceptComponent } from './traineraccept/traineraccept.component';
import { UserrequestComponent } from './userrequest/userrequest.component';
import { Profile1Component } from './profile1/profile1.component';
import { Profile2Component } from './profile2/profile2.component';
import { Profile3Component } from './profile3/profile3.component';
import { Profile4Component } from './profile4/profile4.component';
import { CompletedComponent } from './completed/completed.component';
import { InprogressComponent } from './inprogress/inprogress.component';
import { UserprofileComponent } from './userprofile/userprofile.component';
import { EditskillsComponent } from './editskills/editskills.component';


const routes: Routes = [
  { path: '', redirectTo: '/navbar', pathMatch: 'full' },
  { path: 'header', component: HeaderComponent },
  { path: 'navbar', component: NavbarComponent },
  { path: 'searchheader', component: SearchheaderComponent },
  { path: 'searchnavbar', component: SearchnavbarComponent },
  { path: 'searchbody', component: SearchbodyComponent },
  { path: 'signup', component: SignupComponent },
  { path: 'signin', component: SigninComponent },
  { path: 'signin1', component: Signin1Component },
  { path: 'payment', component: PaymentComponent },
  { path: 'aboutus', component: AboutusComponent },
  { path: 'blocktrainer', component: BlocktrainerComponent },
  { path: 'blockuser', component: BlockuserComponent },
  { path: 'addedit', component: AddeditComponent },
  { path: 'traineraccept', component: TraineracceptComponent },
  { path: 'userrequest', component: UserrequestComponent },
  { path: 'profile1', component: Profile1Component },
  { path: 'profile2', component: Profile2Component },
  { path: 'profile3', component: Profile3Component },
  { path: 'profile4', component: Profile4Component },
  { path: 'completed', component: CompletedComponent },
  { path: 'inprogress', component: InprogressComponent },
  { path: 'userprofile', component: UserprofileComponent },
  { path: 'editskills', component: EditskillsComponent }



];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
