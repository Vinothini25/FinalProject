import { Component, OnInit } from '@angular/core';
import { Router,ActivatedRoute, RouterLink } from '@angular/router';
import { FormBuilder, FormGroup,Validators } from '@angular/forms';


@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.css']
})
export class SigninComponent implements OnInit {
  signinForm:FormGroup;
  loading=false;
  submitted=false;
  returnUrl:string;

  constructor(
    private formBuilder: FormBuilder,
    private route:ActivatedRoute,
    private router: Router,
  ) { }

  ngOnInit() {
    this.signinForm=this.formBuilder.group({
      username: ['',[Validators.required,Validators.email]],
      password: ['',Validators.required]
    });
    this.returnUrl=this.route.snapshot.queryParams['returnUrl'] || '/';
  }
  get f() { return this.signinForm.controls;}
  onSubmit(){
    this.submitted=true;
    if(this.signinForm.invalid){
      return;
    }
    this.router.navigateByUrl('/userrequest');
  }

}
