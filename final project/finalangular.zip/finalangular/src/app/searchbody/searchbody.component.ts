import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-searchbody',
  templateUrl: './searchbody.component.html',
  styleUrls: ['./searchbody.component.css']
})
export class SearchbodyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
