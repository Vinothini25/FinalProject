package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.demo.model.Role;
import com.example.demo.model.User;
import com.example.demo.model.UserCompletedTraining;
import com.example.demo.model.UserCurrentTraining;
import com.example.demo.model.UserDetails;
import com.example.demo.repository.RoleRepository;
import com.example.demo.service.UserService;

@Controller    
@CrossOrigin(origins="http://localhost:4200")  
public class MainController {
	@Autowired
	private UserService userService;
	
	@PostMapping(path="/role")
	public @ResponseBody String role(@RequestBody Role r) {
		userService.saveRole(r);
		return "saved";
		
	}
	
	@GetMapping("/findcompleted/{username}")
	public @ResponseBody List<UserCompletedTraining>  findcompleted(@PathVariable String username){
		
return userService.searchCompleted(username);
	}
	@GetMapping("/findcurrent/{username}")
	public @ResponseBody List<UserCurrentTraining>  findcurrent(@PathVariable String username){
		
return userService.searchCurrent(username);
	}
	@PostMapping("/save")
	public @ResponseBody String saveUserDetails(@RequestBody UserDetails u){
		userService.saveUserDetails(u);
		return "stored";
	}
	@PostMapping("/saveuser")
	public @ResponseBody String saveUser(@RequestBody User u){
		userService.saveUser(u);
		return "stored";
	}
	@GetMapping("/finduser/{username}")
	public @ResponseBody User  finduser(@PathVariable String username){
		
return userService.findUser(username);
	}
	@GetMapping("/savecurrent/{username}/{technology}")
	public @ResponseBody String savecurrent(@PathVariable String username,@PathVariable String technology) {
		userService.savecurrent(username,technology);
		return "stored";
	}

}
