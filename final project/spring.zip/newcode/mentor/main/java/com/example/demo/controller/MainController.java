package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.demo.model.Mentor;
import com.example.demo.model.MentorCompletedTraining;
import com.example.demo.model.MentorCurrentTraining;
import com.example.demo.model.User;
import com.example.demo.service.MentorService;



@Controller
@CrossOrigin(origins="http://localhost:4200")
public class MainController {
	@Autowired
	private MentorService mentorservice;
	
		@GetMapping("/findmentor/{username}")
	public @ResponseBody Mentor findMentor(@PathVariable String username) {
		return mentorservice.findMentor(username);
	}
	
	@PostMapping("/save")
	public @ResponseBody String saveUser(@RequestBody Mentor m){
		mentorservice.saveMentorDetails(m);
		return "stored";
	}
	@PostMapping("/savementor")
	public @ResponseBody String savementor(@RequestBody User u){
		mentorservice.saveMentor(u);
		return "stored";
	}
	
	
	@GetMapping("/findcompleted/{username}")
	public @ResponseBody List<MentorCompletedTraining>  findcompleted(@PathVariable String username){
		
return mentorservice.searchCompleted(username);
	}
	@GetMapping("/findcurrent/{username}")
	public @ResponseBody List<MentorCurrentTraining>  findcurrent(@PathVariable String username){
		
return mentorservice.searchCurrent(username);
	}

}
