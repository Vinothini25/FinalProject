import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../service.service';
import { ActivatedRoute } from '@angular/router';
import { MentorserviceService } from '../mentorservice.service';

@Component({
  selector: 'app-mentormenu',
  templateUrl: './mentormenu.component.html',
  styleUrls: ['./mentormenu.component.css']
})
export class MentormenuComponent implements OnInit {

  private technology=[];
  private skill=[];
  private name:string;
  displayvalue:boolean=false;
  displaycurrent:boolean=false;
  displaycomplete:boolean=false;
  username:string;
    constructor(private trainer:MentorserviceService,private router:ActivatedRoute) { }
  
    ngOnInit() {
      this.username=this.router.snapshot.paramMap.get('username');
    }
  
  showcurrent(){
    this.displayvalue=false;
    this.displaycomplete=false;
    this.displaycurrent=true;
    this.trainer.getCurrent(this.username)
  .subscribe(value =>this.technology=value as string[]);
  }
  showcomplete(){
    this.displayvalue=false;
    this.displaycomplete=true;
    this.displaycurrent=false;
    this.trainer.getCompleted(this.username)
    .subscribe(value =>this.technology=value as string[]);
  }
  showskills(){
    this.displayvalue=true;
    this.displaycomplete=false;
    this.displaycurrent=false;
    this.trainer.getSkill(this.username).subscribe(value=>this.skill=value as string[]);
    console.log(this.skill);
  }
  }
  


