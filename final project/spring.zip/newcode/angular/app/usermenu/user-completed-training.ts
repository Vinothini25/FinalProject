export class UserCompletedTraining {
id:number;
technology:string;
duration:string;
userid:number;
}
