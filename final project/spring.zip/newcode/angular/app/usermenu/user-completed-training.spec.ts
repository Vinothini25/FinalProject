import { UserCompletedTraining } from './user-completed-training';

describe('UserCompletedTraining', () => {
  it('should create an instance', () => {
    expect(new UserCompletedTraining()).toBeTruthy();
  });
});
