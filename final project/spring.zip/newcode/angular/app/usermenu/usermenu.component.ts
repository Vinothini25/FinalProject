import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../service.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-usermenu',
  templateUrl: './usermenu.component.html',
  styleUrls: ['./usermenu.component.css']
})
export class UsermenuComponent implements OnInit {
private trainers=[];
private mentor=[];
private time=[];
tech:string;
username:string;
private technology=[];
displayvalue:boolean=false;
displaycurrent:boolean=false;
displaycomplete:boolean=false;
displaytech:boolean=false;
  constructor(private trainer:ServiceService,private router:ActivatedRoute) { }

  ngOnInit() {
    this.username=this.router.snapshot.paramMap.get('username');
  }
showsearch(){
this.displayvalue=true;
this.displaycurrent=false;
this.displaycomplete=false;
this.displaytech=false;
  this.trainer.findMentor()
  .subscribe(data =>this.mentor=data as string[]);
}
showcurrent(){
  this.displayvalue=false;
  this.displaycomplete=false;
  this.displaycurrent=true;
  this.displaytech=false;
  this.trainer.getCurrent(this.username)
  .subscribe(value =>this.technology=value as string[]);
}
showcomplete(){
  this.displayvalue=false;
  this.displaycomplete=true;
  this.displaycurrent=false;
  this.displaytech=false;
  this.trainer.getCompleted(this.username)
  .subscribe(value =>this.technology=value as string[]);
}
search(){
  this.displayvalue=false;
  this.displaycomplete=false;
  this.displaycurrent=false;
  this.displaytech=true;
  this.trainer.searchMentor(this.tech)
    .subscribe(value =>this.trainers=value as string[]);
    
    this.trainer.searchMentortime(this.tech)
    .subscribe(value =>this.time=value as string[]);
}
propose(technology){
  this.trainer.savecurrent(this.username,technology).subscribe();
}
}
