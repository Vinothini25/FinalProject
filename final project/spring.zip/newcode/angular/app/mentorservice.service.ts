import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MentorserviceService {
private url="http://localhost:8080/api";
 
   
  constructor(private http:HttpClient) { }

  getTechnology():Observable<any> {  
    return this.http.get(`${this.url}/admin/findadmintechnology`);  
  }
  savementor(mentor:object):Observable<any>{
    return this.http.post(`${this.url}/mentor/save`,mentor);
  }
  savetechnology(username:string,technology:string):Observable<any>{
    return this.http.get(`${this.url}/course/savetechnology/${username}/${technology}`);
  }
  savetime(username:string,time:string):Observable<any>{
    return this.http.get(`${this.url}/course/savetime/${username}/${time}`);
  }
  savementorlogin(mentor:object):Observable<any>{
    return this.http.post(`${this.url}/mentor/savementor`,mentor);
  }
  getCompleted(username: string) {  
    return this.http.get(`${this.url}/mentor/findcompleted/${username}`);  
  }
    getCurrent(username:string) {  
    return this.http.get(`${this.url}/mentor/findcurrent/${username}`);  
  }
  getSkill(username:string){
    return this.http.get(`${this.url}/course/findskill/${username}`);
  }
}
