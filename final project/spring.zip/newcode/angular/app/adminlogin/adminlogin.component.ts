import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-adminlogin',
  templateUrl: './adminlogin.component.html',
  styleUrls: ['./adminlogin.component.css']
})
export class AdminloginComponent implements OnInit {
username:string;
password:string;
  constructor(private router:Router) { }

  ngOnInit() {
  }
  validate(){
    if(this.username==null){
      alert("Enter username");
      
    }
    else if(this.password==null){
      alert("Enter password")
    }
  else{
  this.router.navigate(['/adminmenu']);
  }
  }
}
