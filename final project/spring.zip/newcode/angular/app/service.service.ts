import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders  } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
export class User{
  constructor(
    public status:string,
     ) {}
  
}

@Injectable({
  providedIn: 'root'
})
export class ServiceService {
  url:string="/assets/data.json";
  url1:string="/assets/value.json";
  url2:string="/assets/data2.json";
  private baseUrl = 'http://localhost:8080/api'; 
   
  constructor(private http:HttpClient) { }
  getTrainer(){
  
    return this.http.get(this.url);
  }
  getTechnology(){
  
    return this.http.get(this.url1);
  }
  getPayment(){
    return this.http.get(this.url2);
  }
  getCompleted(username: string) {  
    return this.http.get(`${this.baseUrl}/User/findcompleted/${username}`);  
  }
    getCurrent(username:string) {  
    return this.http.get(`${this.baseUrl}/User/findcurrent/${username}`);  
  }
  getUser(username:string):Observable<any> {  
    return this.http.get(`${this.baseUrl}/User/finduser/${username}`);  
  }

  createUser(user: object): Observable<object> {  
    return this.http.post(`${this.baseUrl}/User/`+'save', user);  
  } 
  createUserRegister(userregister:object):Observable<object>{
    return this.http.post(`${this.baseUrl}/User/`+'saveuser', userregister);
  }
  searchMentor(technology:string):Observable<any> {  
    return this.http.get(`${this.baseUrl}/course/findtechnology/${technology}`);  
  }
  searchMentortime(time:string):Observable<any> {  
    return this.http.get(`${this.baseUrl}/course/findtimesearch/${time}`);  
  }
  findMentor():Observable<any> {  
    return this.http.get(`${this.baseUrl}/course/findmentorlist/`);  
  }
  savecurrent(username:string,technology:string){
    return this.http.get(`${this.baseUrl}/User/savecurrent/${username}/${technology}`); 
  }
 
  authenticate(username, password) {
    const headers = new HttpHeaders({ Authorization: 'Basic ' + btoa(username + ':' + password) });
    return this.http.get<User>('http://localhost:8070/authenticate',{headers}).pipe(
     map(
       userData => {
        sessionStorage.setItem('username',username);
        return userData;
       }
     )

    );
  }


isUserLoggedIn() {
  let user = sessionStorage.getItem('username')
  console.log(!(user === null))
  return !(user === null)
}

logOut() {
  sessionStorage.removeItem('username')
}
  }

  

