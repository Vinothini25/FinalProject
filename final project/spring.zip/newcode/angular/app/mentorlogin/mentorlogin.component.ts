import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { ServiceService } from '../service.service';
import { Userregister } from '../usersignup/userregister';

@Component({
  selector: 'app-mentorlogin',
  templateUrl: './mentorlogin.component.html',
  styleUrls: ['./mentorlogin.component.css']
})
export class MentorloginComponent implements OnInit {
username:string;
password:string;
invalidLogin :boolean=false;
 userlogin:Userregister=new Userregister();
  constructor(private router:Router,private service:ServiceService) { }

  ngOnInit() {
  }
  validate(){
    if(this.username==null){
      alert("Enter username");
      
    }
    else if(this.password==null){
      alert("Enter password")
    }
  else{
    this.service.getUser(this.username).subscribe(value=>this.userlogin=value);
    if(this.userlogin.username==this.username && this.userlogin.password==this.password){
    
  this.router.navigate(['/mentormenu',this.username]);
  this.invalidLogin = false;
    }
else{
  this.invalidLogin=true;
}
    }
  }
}
